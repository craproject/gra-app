//import { MyInfoMapping } from "@/data/myInfoMapping";

export class ApplicantDataModel {
    nameOfApplicant;
    entityType;
    entityType_other;
    natureEntity;
    natureEntity_other;
    uen;
    descriptionOfOperations;
    postalCode;
    address;
    businessTelephoneNumber;
    websiteAddress;
    emailAddress;
    emailCheckbox;
    dateOfAppointment;

}
