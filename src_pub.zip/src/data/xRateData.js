export function getExRateData() {
	return [
		{ Id: "7b1384ba-b4c8-eb11-9676-005056b57f58", Value: 0.00005739 },
		{ Id: "9d42069a-fcbc-eb11-9676-005056b57f58", Value: 1.61290 },
		{ Id: "91f9b571-bbae-eb11-966c-005056b57f58", Value: 1.00000 },
		{ Id: "1f5ca3ee-91c7-eb11-9676-005056b57f58", Value: 1.31578 },
	];
}