import age from "./age";
import integer from "./integer";
import { nricValidator, SCnricValidator, NCnricValidator } from "./nric";
export { age, integer, nricValidator, SCnricValidator, NCnricValidator };
