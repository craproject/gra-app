export default {
    data() {
        return {
            optionData: {},
            countryOptions:[],
            currencyOptions:[],
            raceOptions:[],
            tattooOptions:[],
            bodyOptions:[],
            citizenshipOptions:[],
            propertyOptions:[],
            genderOptions: [
                { value: "100000000", label: "Male" },
                { value: "100000001", label: "Female" }
            ],
            citizenshipTypeOptions: [
                { value: "100000000", label: "Singapore Citizen" },
                { value: "100000001", label: "Permanent Resident" },
                { value: "100000002", label: "Work Pass Holder" },
                { value: "100000003", label: "Others" }
            ],
            entityTypeOptions: [
                { value: "100000000", label: "Company registered with ACRA" },
                { value: "100000001", label: "Society registered with ROS" },
                { value: "100000002", label: "Others" }
            ],
            natureEntityOptions: [
                { value: "100000000", label: "Recreational club" },
                { value: "100000001", label: "Others" }
            ],
            salutationTypeOptions:[
                { value: "100000000", label: "Mr" },
                { value: "100000001", label: "Mrs" },
                { value: "100000002", label: "Ms" },
                { value: "100000003", label: "Mdm" },
                { value: "100000004", label: "Dr" }
            ],
            foreignCitizenshipOptions: [
                { value: "100000000", label: "Citizen" },
                { value: "100000001", label: "Permanent Resident" }
            ],
            addressTypeOptions: [
                { value: "100000000", label: "Apt Blk" },
                { value: "100000001", label: "Without Apt Blk" },
                { value: "100000002", label: "Overseas Address" },
                { value: "100000003", label: "Private Flats With Apt Blk" },
                { value: "100000004", label: "C/O Apt Blk" },
                { value: "100000005", label: "C/O Without Apt Blk" },
                { value: "100000006", label: "Quarter Address" },
                { value: "100000007", label: "Island Address" },
                { value: "100000008", label: "Reverse of AptBlk & StrName" },
                { value: "100000009", label: "NIL" }
            ],
            scarOptions: [
                { value: "100000000", label: "Marks" },
                { value: "100000001", label: "Scars" },
                { value: "100000002", label: "Tattoos" },
                { value: "100000003", label: "Characteristics" }
            ],
            // tattooOptions: [
            //     { value: "6b394ffa-7ac3-eb11-9676-005056b57f58", label: "Amphibian" },
            //     {
            //         value: "6c394ffa-7ac3-eb11-9676-005056b57f58",
            //         label: "Animal Forms - Mythology"
            //     },
            //     { value: "4390b605-7bc3-eb11-9676-005056b57f58", label: "Bird" },
            //     { value: "4490b605-7bc3-eb11-9676-005056b57f58", label: "Characters" },
            //     {
            //         value: "d0797f0e-7bc3-eb11-9676-005056b57f58",
            //         label: "Fantasy / Fairy Tale / Cartoon"
            //     }
            //     /*{ value: "00000000-0000-0000-0000-000000000006", label: "fish" },
            //      { value: "00000000-0000-0000-0000-000000000007", label: "human likeness - mythology / religion" },
            //      { value: "00000000-0000-0000-0000-000000000008", label: "insects" },
            //      { value: "00000000-0000-0000-0000-000000000009", label: "insignias / symbols" },
            //      { value: "00000000-0000-0000-0000-000000000010", label: "mammal in animal form" },
            //      { value: "00000000-0000-0000-0000-000000000011", label: "mammal in human form" },
            //      { value: "00000000-0000-0000-0000-000000000012", label: "mixture" },
            //      { value: "00000000-0000-0000-0000-000000000013", label: "objects" },
            //      { value: "00000000-0000-0000-0000-000000000014", label: "plants / trees" },
            //      { value: "00000000-0000-0000-0000-000000000015", label: "reptile" },
            //      { value: "00000000-0000-0000-0000-000000000016", label: "shapes" },
            //      { value: "00000000-0000-0000-0000-000000000017", label: "shellfish" },
            //      { value: "00000000-0000-0000-0000-000000000018", label: "unknown" },
            //      { value: "00000000-0000-0000-0000-000000000019", label: "others" },*/
            // ],
            // bodyOptions: [
            //     { value: "3c6e9a32-7bc3-eb11-9676-005056b57f58", label: "Ankle" },
            //     { value: "3d6e9a32-7bc3-eb11-9676-005056b57f58", label: "Arm" },
            //     { value: "53c0fc38-7bc3-eb11-9676-005056b57f58", label: "Back of body" },
            //     { value: "54c0fc38-7bc3-eb11-9676-005056b57f58", label: "Belly" },
            //     { value: "99d49c3f-7bc3-eb11-9676-005056b57f58", label: "Breast" },
            //     { value: "9ad49c3f-7bc3-eb11-9676-005056b57f58", label: "Buttock" },
            //     { value: "f6323446-7bc3-eb11-9676-005056b57f58", label: "Calf" },
            //     { value: "f7323446-7bc3-eb11-9676-005056b57f58", label: "Chest" },
            //     { value: "f8323446-7bc3-eb11-9676-005056b57f58", label: "Chin" },
            //     { value: "8c08464f-7bc3-eb11-9676-005056b57f58", label: "Ear" }
            //     /*{ value: "00000000-0000-0000-0000-000000000011", label: "eyebrow" },
            //      { value: "00000000-0000-0000-0000-000000000012", label: "eye" },
            //      { value: "00000000-0000-0000-0000-000000000013", label: "elbow" },
            //      { value: "00000000-0000-0000-0000-000000000014", label: "eyelid" },
            //      { value: "00000000-0000-0000-0000-000000000015", label: "forearm" },
            //      { value: "00000000-0000-0000-0000-000000000016", label: "face" },
            //      { value: "00000000-0000-0000-0000-000000000017", label: "forehead" },
            //      { value: "00000000-0000-0000-0000-000000000018", label: "finger" },
            //      { value: "00000000-0000-0000-0000-000000000019", label: "front of body" },
            //      { value: "00000000-0000-0000-0000-000000000020", label: "foot" },
            //      { value: "00000000-0000-0000-0000-000000000021", label: "groin" },
            //      { value: "00000000-0000-0000-0000-000000000022", label: "hand" },
            //      { value: "00000000-0000-0000-0000-000000000023", label: "hip" },
            //      { value: "00000000-0000-0000-0000-000000000024", label: "jaw" },
            //      { value: "00000000-0000-0000-0000-000000000025", label: "knee" },
            //      { value: "00000000-0000-0000-0000-000000000026", label: "leg" },
            //      { value: "00000000-0000-0000-0000-000000000027", label: "lips" },
            //      { value: "00000000-0000-0000-0000-000000000028", label: "mouth" },
            //      { value: "00000000-0000-0000-0000-000000000029", label: "neck" },
            //      { value: "00000000-0000-0000-0000-000000000030", label: "nose" },
            //      { value: "00000000-0000-0000-0000-000000000031", label: "navel" },
            //      { value: "00000000-0000-0000-0000-000000000032", label: "side of body" },
            //      { value: "00000000-0000-0000-0000-000000000033", label: "shoulder" },
            //      { value: "00000000-0000-0000-0000-000000000034", label: "shin" },
            //      { value: "00000000-0000-0000-0000-000000000035", label: "teeth" },
            //      { value: "00000000-0000-0000-0000-000000000036", label: "thigh" },
            //      { value: "00000000-0000-0000-0000-000000000037", label: "toe" },
            //      { value: "00000000-0000-0000-0000-000000000038", label: "upper arm" },
            //      { value: "00000000-0000-0000-0000-000000000039", label: "waist" },
            //      { value: "00000000-0000-0000-0000-000000000040", label: "whole body" },
            //      { value: "00000000-0000-0000-0000-000000000041", label: "wrist" },*/
            // ],
            ownershipOptions: [
                { value: "100000000", label: "Own" },
                { value: "100000001", label: "Rent" },
                { value: "100000002", label: "Parents" },
                { value: "100000003", label: "Others" }
            ],
            maritalOptions: [
                { value: "100000000", label: "Single" },
                { value: "100000001", label: "Engaged" },
                { value: "100000002", label: "Married" },
                { value: "100000003", label: "Cohabited" },
                { value: "100000004", label: "Separated" },
                { value: "100000005", label: "Divorced" },
                { value: "100000006", label: "Widowed" }
            ],
            relationshipOptions: [
                { value: "100000000", label: "Father" },
                { value: "100000001", label: "Mother" },
                { value: "100000002", label: "Daughter" },
                { value: "100000003", label: "Son" },
                { value: "100000004", label: "Brother" },
                { value: "100000005", label: "Sister" },
                { value: "100000006", label: "Father-in-law" },
                { value: "100000007", label: "Mother-in-law" },
                { value: "100000008", label: "Brother-in-law" },
                { value: "100000009", label: "Sister-in-law" },
                { value: "100000010", label: "Others" }
            ],
            qualificationOptions: [
                { value: "100000000", label: "Sec Edn w/o GCE 'O' or 'N' pass" },
                { value: "100000001", label: "GCE 'N' Level" },
                { value: "100000002", label: "GCE 'O' Level" },
                { value: "100000003", label: "Vocational Institute" },
                { value: "100000004", label: "Trade Certificate" },
                { value: "100000005", label: "Technical Institute" },
                { value: "100000006", label: "Other Sec Sch Leaving Exam Cert" },
                { value: "100000007", label: "GCE 'A' Level" },
                { value: "100000008", label: "Certificate/Diploma" },
                { value: "100000009", label: "Bachelor Degree" },
                { value: "100000010", label: "Honours" },
                { value: "100000011", label: "Postgraduate Diploma" },
                { value: "100000012", label: "Master Degree" },
                { value: "100000013", label: "Doctorate" },
                { value: "100000014", label: "Others" }
            ],
            businessOptions: [
                { value: "00000000-0000-0000-0000-000000000001", label: "Live" },
                { value: "00000000-0000-0000-0000-000000000002", label: "Terminated" },
                { value: "00000000-0000-0000-0000-000000000003", label: "Cancelled" },
                {
                    value: "00000000-0000-0000-0000-000000000004",
                    label: "Cancellation in progress"
                },
                { value: "00000000-0000-0000-0000-000000000005", label: "In receivership" },
                { value: "00000000-0000-0000-0000-000000000006", label: "To be terminated" },
                { value: "00000000-0000-0000-0000-000000000007", label: "Judicial management" },
                { value: "00000000-0000-0000-0000-000000000008", label: "In liquidation" },
                { value: "00000000-0000-0000-0000-000000000009", label: "Ceased" },
                { value: "00000000-0000-0000-0000-000000000010", label: "Converted to LLP" },
                {
                    value: "00000000-0000-0000-0000-000000000011",
                    label: "Registration expired and has not been renewed"
                },
                { value: "00000000-0000-0000-0000-000000000012", label: "Others" }
            ],
            applicationOptions: [
                { value: "100000000", label: "Granted" },
                { value: "100000001", label: "Denied" },
                { value: "100000002", label: "Pending" }
            ],
            chargeOptions: [],
            businessStatusOptions: [
                { value: "100000000", label: "Amalgamated" },
                { value: "100000001", label: "Ceased Registration" },
                { value: "100000002", label: "Converted to LLP" },
                { value: "100000003", label: "Dissolved (Foreign CO)" },
                { value: "100000004", label: "Dissolved - Compulsory Winding up (Insolvency)" },
                { value: "100000005", label: "Dissolved - Creditors' Voluntary Winding up" },
                { value: "100000006", label: "Dissolved - Members' Voluntary Winding up" },
                {
                    value: "100000007",
                    label: "Dissolved - Pursuant to Section 212(1)(D0 of the Companies Act"
                },
                { value: "100000008", label: "Gazetted to be Struck off" },
                { value: "100000009", label: "In Liquidation (Foreign CO)" },
                { value: "100000010", label: "In Liquidation - Compulsory Winding" },
                {
                    value: "100000011",
                    label: "In Liquidation - Compulsory Winding up (Insolvency)"
                },
                { value: "100000012", label: "In Liquidation - Creditors' Voluntary Winding up" },
                { value: "100000013", label: "In Liquidation - Members' Voluntary Winding up" },
                { value: "100000014", label: "In Receivership" },
                { value: "100000015", label: "Live Company" },
                { value: "100000016", label: "Registration Expired and has not been Renewed" },
                { value: "100000017", label: "Struck off" },
                { value: "100000018", label: "Terminated" },
                { value: "100000019", label: "To be Terminated" },
                { value: "100000020", label: "Under Judicial Management" },
                { value: "100000021", label: "Others" }
            ],
            accountOptions: [
                { value: "100000000", label: "Savings" },
                { value: "100000001", label: "Joint" },
                { value: "100000002", label: "Fixed Deposit" },
                { value: "100000003", label: "Current Account" }
            ],
            // propertyOptions: [
            //     { value: "100000000", label: "Government Housing" },
            //     { value: "100000001", label: "Condominium" },
            //     { value: "100000002", label: "Landed" },
            //     { value: "100000003", label: "Shop house" },
            //     { value: "100000004", label: "Others" }
            // ],
            singleJointOptions: [
                { value: "100000000", label: "Single" },
                { value: "100000001", label: "Joint" }
            ],
            creditorOptions: [
                { value: "100000000", label: "Financial institution" },
                { value: "100000001", label: "Licensed money lender" },
                { value: "100000002", label: "Unlicensed money lender" },
                { value: "100000003", label: "Others" }
            ],
            payablesOptions: [
                { value: "100000000", label: "Credit card" },
                { value: "100000001", label: "Renovation loan" },
                { value: "100000002", label: "Study loan" },
                { value: "100000003", label: "Personal loan" },
                { value: "100000004", label: "Lines of credit / overdrafts" },
                { value: "100000005", label: "Instalment loan" },
                { value: "100000006", label: "Hire purchase" },
                { value: "100000007", label: "Others" }
            ],
            taxOptions: [
                { value: "100000000", label: "Income tax" },
                { value: "100000001", label: "Property tax" }
            ],
            mortgageOptions: [
                { value: "100000000", label: "Mortgage" },
                { value: "100000001", label: "Bridging loan" }
            ],
            loansOptions: [
                { value: "100000000", label: "Securities" },
                { value: "100000001", label: "Insurance" },
                { value: "100000002", label: "Pension plan" }
            ],
            yesNoOptions: [
                { value: "Yes", label: "Yes" },
                { value: "No", label: "No" }
            ],
            // countryOptions: [
            //     { value: "09b03876-6ab1-eb11-966c-005056b57f58", label: "Japan" },
            //     { value: "9853ce96-69b1-eb11-966c-005056b57f58", label: "Singapore" }
            //     //{ value: "3bfe8fc1-d94a-4082-b99d-90d7322a5580", label: "From API" }
            // ],
            // citizenshipOptions: [
            //     { value: "c7690930-7fc3-eb11-9676-005056b57f58", label: "Singaporean" }
            // ],
            // currencyOptions: [
            //     { value: "7b1384ba-b4c8-eb11-9676-005056b57f58", label: "VND" },
            //     { value: "9d42069a-fcbc-eb11-9676-005056b57f58", label: "EUR" },
            //     { value: "91f9b571-bbae-eb11-966c-005056b57f58", label: "SGD" },
            //     { value: "1f5ca3ee-91c7-eb11-9676-005056b57f58", label: "USD" }
            // ],
            // raceOptions: [
            //     { value: "f8ec0c20-7ac3-eb11-9676-005056b57f58", label: "Chinese" },
            //     { value: "45a62826-7ac3-eb11-9676-005056b57f58", label: "Malay" },
            //     { value: "7de04e20-83b7-eb11-966c-005056b57f58", label: "Test" }
            // ],
            informationNilOptions: [
                { value: "Yes", label: "Information To Provide" },
                { value: "No", label: "Nil" }
            ],
            programOptions: [
                { value: "100000000", label: "DCP" },
                { value: "100000001", label: "DMP" },
                { value: "100000002", label: "DRS" },
                { value: "100000003", label: "AKPK" },
                { value: "100000004", label: "Others" }
            ],
            vehicleLoanOptions: [
                { value: "100000000", label: "Fully Paid" },
                { value: "100000001", label: "Bank Loan" },
                { value: "100000002", label: "In-house Loan" }
            ],
            attachmentStatusOptions: [
                { value: "Yes", label: "Yes" },
                { value: "Pending", label: "Pending" },
                { value: "N.A.", label: "N.A." }
            ]
        };
    },
    methods: {
        getOptionText(option, value) {
            return option.find(opt => opt.value === value)?.label ?? "";
        },
        getOptionValue(option, text) {
            return option.find(opt => opt.label === text)?.value ?? "";
        },
        getCurrencyCode(option, value){
            return option.find(opt => opt.Id === value)?.CurrencyCode ?? "";
        },
        getOptionTextForName(option, value) {
            return option.find(opt => opt.value === value)?.name ?? "";
        },
    },
    async beforeMount() {
        this.optionData = await await (await fetch("data/options.json")).json();
        this.countryOptions = this.optionData['Country_Master'];
        this.currencyOptions = this.optionData['Currency_Master'];
        this.raceOptions = this.optionData['Race_Master'];
        this.tattooOptions=this.optionData['Tattoo_Patterns_Master'];
        this.bodyOptions = this.optionData['Tattoo_Locations_Master'];
        this.citizenshipOptions = this.optionData['Citizenship_Master'];
        this.propertyOptions = this.optionData['Property_Type_Options'];
        this.accountOptions = this.optionData['Account_Options'];
        this.chargeOptions=this.optionData['Charge_Options']
    }
};
