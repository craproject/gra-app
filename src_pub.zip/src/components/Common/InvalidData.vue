<template>
    <v-chip color="red" small dark>
        Value is required
    </v-chip>
</template>

<script>
export default {
    name: "InvalidData"
};
</script>

<style scoped></style>
